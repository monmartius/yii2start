### Accordion.JS
---

A free, lightweight jQuery Accordion plugin. It is only ~1KB gzipped. Configurable using direct options and HTML5 data-* attributes.

#### Demo and docs: https://accordion.js.org
#### License: MIT

[![NPM](https://nodei.co/npm/accordionjs.png?compact=true)](https://nodei.co/npm/accordionjs/)

### Changelog:

**2.1.1**
 * Github `docs/` update.
 * Distribution files moved out from `dist` folder to root folder. No reasons to keep them in `dist`.
 * Removed comments from `.jshitrc` because they looks invalid on github.
 * Added `.gitignore`

**2.1.0**
 * Second major release. Complete code refactoring.
